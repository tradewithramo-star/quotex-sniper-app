import streamlit as st
import random
import time

st.set_page_config(page_title="Quotex Sniper", layout="centered")

st.title("📈 Quotex Sniper Recovery App")
st.markdown("### Conservative Auto Signals (5s, 1m, 2m Expiry)")

pair = st.selectbox("Select Pair", ["EUR/USD", "GBP/JPY", "USD/JPY", "AUD/USD"])
expiry = st.selectbox("Select Expiry", ["5 seconds", "1 minute", "2 minutes"])

if st.button("Get Signal"):
    with st.spinner("Analyzing market..."):
        time.sleep(2)
    signal = random.choice(["CALL 📈", "PUT 📉"])
    st.success(f"Signal: **{signal}** for {pair} [{expiry}]")
    st.balloons()